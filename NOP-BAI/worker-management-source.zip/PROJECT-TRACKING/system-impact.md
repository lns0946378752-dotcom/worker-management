# Diem anh huong toan he thong

## Trang thai tong quan — 2026-10-24

- **May ghi nhan:** `SANG-ADMIN`
- **Repo/branch/commit luc ghi:** `lns0946378752-dotcom/worker-management`, `main`, `98e9625`
- **Kien truc chinh:** React + Vite frontend; Express + TypeScript backend theo routes/controllers/services/Sequelize models; SQL Server.
- **Nguon chuan cho yeu cau:** `docs/YEU-CAU-DO-AN-CUOI-KHOA.md` va rubric cua giang vien trong `SKILL/`.
- **Quy uoc thay doi:** Kiem tra Git truoc khi sua; bao toan thay doi chua commit; cap nhat `CHANGE-HISTORY/` sau moi dot lam viec.

## Xac thuc va quyen truy cap

- Dang ky tu tao tai khoan luon gan role `user`; admin duoc tao bang script seed rieng.
- Backend ky va xac minh bearer JWT; secret lay tu `JWT_SECRET` va phai dai it nhat 32 ky tu.
- JWT duoc rang buoc issuer `worker-management`, audience `worker-management-web`, algorithm `HS256`, va han mot gio.
- Middleware tai role hien tai tu database moi request, khong tin role tu client/JWT de cap quyen.
- Frontend giu access token trong bo nho JavaScript; tai lai trang se mat token va can dang nhap lai. Chua co refresh token/cookie auth.
- **Can regression khi sua:** startup validation secret; login/register; `/api/auth/me`; admin/user access; expired/invalid token; CORS/API calls.
- **Trang thai can chu y:** Mot phan refactor JWT da ton tai o worktree truoc dot sua nay, chua commit (`backend/src/utils/access-token.ts` va cac sua doi auth). Da giu nguyen va bo sung test hoi quy; xac minh bang tests/build sau khi hoan tat.
- **Validation/mật khẩu:** email và họ tên được chuẩn hóa; đăng ký chỉ cấp role `user`; mật khẩu bcrypt bị giới hạn tối đa 72 byte UTF-8. Seed Admin mặc định không ghi đè tài khoản; chỉ cờ `--reset-password` mới đổi hash cho tài khoản đã là Admin khớp `ADMIN_EMAIL`.
- **Thông báo API:** lỗi nghiệp vụ, validation, xác thực/phân quyền, rate limit và 404 đã chuyển sang tiếng Việt có dấu; lỗi máy chủ trả câu chung, chi tiết vẫn chỉ ghi log phía server.
- **Test tích hợp:** `npm run test:integration` chạy với SQL Server local, bao gồm đăng ký, hash/persist, duplicate, email sai/đúng, token, User/Admin role, dashboard và rate limit. Không chạy trên production; tài khoản kiểm thử được xóa sau test.

## Database va cau hinh

- Backend doc `.env` tu `backend/` neu co, neu khong doc `.env` o repo root. Chi dung `.env.example` lam mau; secret that khong duoc dua vao Git.
- `database/worker_management.sql` tao database/bang/constraint/index va du lieu demo; Git khong sao luu database dang chay.
- **Mo hinh da xac nhan:** backend chay tren may nay; laptop chay SQL Server. Tao `.env` tren may backend; laptop chi can SQL Server va script database.
- Ket noi SQL Server tu laptop qua LAN can IP/ten host va port that; `localhost` o backend se khong tro toi laptop.
- Huong dan cai dat: [`../SKILL/SQL-Server-Remote-Setup.md`](../SKILL/SQL-Server-Remote-Setup.md).
- **Quyet dinh da xac nhan:** giang vien yeu cau Sequelize ORM de backend ket noi/thao tac SQL Server. Ap dung Sequelize theo rubric; khong chuyen sang stored procedure theo ghi chu tham khao khac neu chua co yeu cau moi tu giang vien. Sequelize khong tu host database; DB hien chay tren laptop trong mang noi bo.
- **Yeu cau da xac nhan:** giang vien yeu cau deploy toan bo he thong len online. Chay DB tren laptop chi la buoc phat trien/kiem thu; neu laptop chuyen sang mang khac thi backend o may nay thuong se mat ket noi toi SQL Server qua LAN.
- **Huong trien khai de xuat, chua chot nha cung cap:** deploy frontend, Express API va SQL Server tuong thich (vi du Azure SQL) len cac dich vu online; dat API URL/CORS va credentials qua environment variables cua hosting. Nen de API noi toi database qua ket noi/private network neu nha cung cap ho tro; khong public SQL port truc tiep.
- Cac lua chon hosting, tai khoan/chi phi, domain va cach migrate schema/data tu laptop len cloud chua duoc xac nhan. Khong tu tao tai khoan, bat dau trial tinh phi, hay dua secret vao Git.

### Demo online tam thoi (2026-10-24)

- Nguoi dung chon uu tien co ban online som: Vercel frontend + Node API host rieng + Supabase PostgreSQL.
- `backend/src/config/database.ts` van mac dinh `DB_DIALECT=mssql` cho local; `DB_DIALECT=postgres` bat PostgreSQL cho hosted demo. Sequelize van la ORM.
- `database/supabase_schema.sql` la schema Postgres rieng, khong duoc chay `worker_management.sql` (T-SQL) tren Supabase.
- Day la thay doi DBMS so voi SQL Server rubric; demo nay chi dung de bao cao som neu chap nhan compromise. Khong migrate/copy data ung vien that; chi dung synthetic data.
- Supabase RLS duoc bat tren cac bang; API su dung ket noi Postgres server-side, khong expose DB credentials hoac Supabase service key ra frontend.
- Chua co project/provider/account duoc tao; khong co secrets cung cap. Chua deploy hay chay PostgreSQL integration test.

## Build va checks

- Lenh tu repo root: `npm test`, `npm run build`, `npm run lint`.
- Tich hop database that chua duoc kiem chung neu may nay chua cau hinh SQL Server va `.env`.
- Kết quả gần nhất trước đợt auth: unit test 19/19 và build backend/frontend đã đạt. Lint đang được chạy lại sau khi sửa script seed; kiểm thử tích hợp từng xác nhận đăng ký/User/token/rate limit, nhưng lượt đầu phát hiện mật khẩu Admin trong DB khác `.env`, nên luồng đăng nhập Admin chưa thể đạt trước khi reset local.
- `.env` local o repo root da duoc tao va Git ignore; SQL login rieng `worker_management_app` chi co quyen doc/ghi trong DB. Khong dung `sa`, khong commit/share secrets, khong public SQL Server ra Internet.

## Admin dashboard

- `GET /api/dashboard` la API moi, dung chung authenticate/role middleware; chi Admin duoc truy cap. Middleware truy van role hien tai tu database, khong tin role do client tu gui.
- Service dem cong ty, vacancy va application bang Sequelize; UI chi hien so tong hop/status, khong tra PII.
- **Can kiem tra regression khi sua:** user/guest khong doc duoc API; Admin nhin thay so khop SQL; lam moi cap nhat ket qua; loi ket noi DB duoc hien ro; UI van dung tren man hinh nho.
- SQL Server local da ket noi; Admin login va metrics dashboard da duoc xac nhan tren DB sample. Chua kiem tra role User/Guest hoac thay doi metrics qua UI.
